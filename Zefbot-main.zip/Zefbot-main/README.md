# Zefbot
Script termux auto view video tiktok terbaru !

<details open><summary><code>Perintah Script?</code></summary>

```python
$ git clone https://github.com/Sxp-ID/Zefbot
$ cd Zefbot
$ python Run.py
```
</details>

## Full tutorialnya?
- Link video <code><a href="https://youtu.be/0spDpbw8cN4?si=ygRaEAtwwP4wSVfb">klik disini</a></code>
- Subs yt admin <code><a href="https://youtube.com/@freetutorialofficial?si=9hamt4Px2gXzPY9x">FREE TUTORIAL</a></code>
<div align="center">

### Jgn lupa kasih star masbro !
</div>
